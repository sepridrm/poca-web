<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-right">
                <ul class="nav">
                    <li class="nav-item">
                        2020 | Dinas Lingkungan Hidup dan Pertanahan Provinsi Sumatera Selatan
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>