

<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-menu icon-gradient bg-mean-fruit"></i>
                    </div>
                    <div>Laporan <?php echo e($title); ?></div>
                </div>
            </div>
        </div>

        <div class="row align-items-center">
            <div class="col-md-12 mx-auto">
                <?php if($visible): ?>
                    <form class="needs-validation" novalidate method="post" action="<?php echo e(route('user.do-tempo')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input value="<?php echo e($title); ?>" name="jenis_laporan" type="hidden" class="form-control">
                        <input value="<?php echo e($loginSession['user_id']); ?>" name="id" type="hidden" class="form-control">
                        <div class="main-card card mb-4">
                            <div class="card-body"><h5 class="card-title">Waktu Laporan</h5>
                                <div class="row">
                                    <div class="pr-3 col-5 mb-4">
                                        <label>Set Waktu Laporan</label>
                                        <div class="input-group"> 
                                            <select name="tempo" class="form-control">
                                                <option value="">Pilih waktu laporan</option>
                                                <option value="1">Per 1 bulan</option>
                                                <option value="3">Per 3 bulan</option>
                                                <option value="6">Per 6 bulan</option>
                                                <option value="12">Per 12 bulan</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="pr-3 col-7 mb-4">
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <button type="button" class="close" aria-label="Close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                                            Waktu laporan digunakan untuk menjadwalkan laporan yang harus diinput yakni per 1, 3, 6, atau 12 bulan.
                                        </div>
                                    </div>

                                    <div class="pr-3 col-12">
                                        <button class="border-1 btn-transition btn btn-outline-success btn-block btn-lg" type="submit">Kirim</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" aria-label="Close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                        Anda memilih waktu laporan per <?php echo e($tempo->tempo); ?> bulan.
                    </div>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" aria-label="Close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                        Anda telah mengunggah <?php echo e($jumlahLaporan); ?> laporan dan belum mengunggah <?php echo e($countLapor); ?> laporan lagi untuk tahun ini.
                    </div>
                <?php endif; ?>

                <form class="needs-validation" novalidate method="post" action="<?php echo e(route('user.do-laporan')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input value="<?php echo e($title); ?>" name="jenis_laporan" type="hidden" class="form-control">
                    <input value="<?php echo e($loginSession['user_id']); ?>" name="id" type="hidden" class="form-control">
                    <div class="main-card card mb-4">
                        <div class="card-body"><h5 class="card-title">Input Laporan</h5>
                            <div class="row">
                                <div class="pr-3 col-6 mb-4">
                                    <label for="">Berkas Laporan</label>
                                    <input type="file" name="path_file[]" class="form-control" autocomplete="off" accept="application/pdf, .doc, .docx, .xls, .xlsx" multiple>
                                </div>

                                <div class="pr-3 col-12">
                                    <?php if($countLapor <= 0): ?>
                                        <button disabled class="border-1 btn-transition btn btn-outline-success btn-block btn-lg" type="submit">Kirim</button>
                                    <?php else: ?>
                                        <button class="border-1 btn-transition btn btn-outline-success btn-block btn-lg" type="submit">Kirim</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

                <div class="main-card card mb-4">
                    <div class="card-body"><h5 class="card-title">Data Laporan</h5>
                        <div class="table-responsive">
                            <table id="table_id" class="mb-0 table table-striped table-hover">
                                <thead>
                                <tr>
                                    <th hidden></th>
                                    <th>#</th>
                                    <th>Tanggal laporan</th>
                                    <th>Berkas laporan</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="data-row">
                                        <td hidden>
                                            <?php echo e($data->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e(($index+1)); ?>

                                        </td>
                                        <td>
                                            <?php echo e($data->created_at); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $path_file = json_decode($data->path_file, true);
                                            ?>
                                            <?php $__currentLoopData = $path_file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(url($item)); ?>">file<?php echo e(($key+1)); ?>/ </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('message')): ?>
                <div class="row justify-content-center">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="position: fixed; bottom: 10px; margin-left: 10px; margin-right: 10px">
                        <button type="button" class="close" aria-label="Close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                        <?php echo e($message); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready( function () {
            $('#table_id').DataTable({
                dom: 'B<"clear">lfrtip',
                buttons: true,
            });
        } );
    </script>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sipp-link\resources\views/contents/user-laporan.blade.php ENDPATH**/ ?>