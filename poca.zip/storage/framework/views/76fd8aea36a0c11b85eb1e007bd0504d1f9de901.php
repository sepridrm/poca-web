

<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-culture icon-gradient bg-mean-fruit"></i>
                    </div>
                    <div>Perusahaan/Instansi</div>
                </div>
            </div>
        </div>

        <div class="row align-items-center">
            <div class="col-md-12 mx-auto">
                <input value="" name="id" type="hidden" class="form-control">
                <div class="main-card card mb-4">
                    <div class="card-body"><h5 class="card-title">Data Perusahaan/Instansi</h5>
                        <div class="row justify-content-center">
                            <div class="table-responsive" style="width: 97%">
                                <table id="table_id" class="mb-0 table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th hidden>Id</th>
                                        <th>#</th>
                                        <th>Nama Perusahaan/Instansi</th>
                                        <th>Alamat</th>
                                        <th>Nomor Telepon</th>
                                        <th>Nomor Fax</th>
                                        <th>Kode KBLI</th>
                                        <th>Jenis Usaha</th>
                                        <th>Nama Pendaftar</th>
                                        <th>Jabatan Pendaftar</th>
                                        <th>Email Pendaftar</th>
                                        <th>Nomor Telpon Pendaftar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $instansiPerusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="data-row">
                                                <td hidden>
                                                    <?php echo e($data->id); ?>

                                                </td>
                                                
                                                <td>
                                                    <?php echo e(($index+1)); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->nama_instansi_usaha); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->kabupaten_kota); ?>, <?php echo e($data->kecamatan); ?> <?php echo e($data->kode_pos_instansi_usaha); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->nomor_telepon_instansi_usaha); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->nomor_fax_instansi_usaha); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->kode_kbli); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->jenis_instansi_usaha); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->nama_pendaftar); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->jabatan_pendaftar); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->email_pendaftar); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->nomor_telepon_pendaftar); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('message')): ?>
                <div class="row justify-content-center">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="position: fixed; bottom: 10px; margin-left: 10px; margin-right: 10px">
                        <button type="button" class="close" aria-label="Close" data-dismiss="alert"><span aria-hidden="true">×</span></button>
                        <?php echo e($message); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready( function () {
            $('#table_id').DataTable({
                dom: 'B<"clear">lfrtip',
                buttons: true,
                responsive: true
            });
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sipp-link\resources\views/contents/admin-instansi-perusahaan.blade.php ENDPATH**/ ?>